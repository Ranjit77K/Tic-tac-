import Tictoe from "./Tictoe";
 const App = () => {
  return (
    <Tictoe/>
  );
}

export default App;
