import React from "react";
import "./Sequare.css";

const Square = ({ onClick, value ,xturn}) => {
  const squareStyle = {
    backgroundColor: value === null && xturn === true ? "red" : value === null && xturn === false ? "blue" : "",
  };

  return (
    <button className="square" onClick={onClick} style={squareStyle}>
      {value}
    </button>
  );
};

export default Square;
