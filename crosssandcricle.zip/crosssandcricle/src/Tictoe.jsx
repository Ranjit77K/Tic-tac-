import React, { useState } from "react";
import Sequare from "./Sequare";
import "./Boxes.css";
import { Button } from "bootstrap";
 
const Tictoe=()=>{
   let [state,setSatate]=useState(Array(9).fill(null));
   let [xturn,setXturn]=useState(false);
   const checkwinner=()=>{
     const iswinner=[
      [0,1,2],
      [3,4,5],
      [6,7,8],
      [0,3,6],
      [1,4,7],
      [2,5,8],
      [0,4,8],
      [2,4,6]
     ];
     for (let logic of iswinner ){
     const [a,b,c]= logic;
     if(state[a] !== null&&state[a]=== state[b]&&state[a]===state[c] ){
      return state[a];
     }}
     return false;
   }
   const winner =checkwinner();

   const handleClick=(index)=>{
    const copystate  =[...state];
    copystate[index]= xturn ? "X" :"O";
    setSatate(copystate);
    setXturn(!xturn);
};
  const resetbtn=()=>{
   setSatate(Array(9).fill(null));
  }

   return(
      <div className="board-container">
         {winner ?(
         <>{winner}  Won The Game </>):(
         <>
         <div className="board-row">
            <Sequare xturn={xturn} onClick={()=>{handleClick(0)}} value={state[0]} />
            <Sequare xturn={xturn} onClick={()=>{handleClick(1)}} value={state[1]}/>
            <Sequare xturn={xturn} onClick={()=>{handleClick(2)}}  value={state[2]}/>
            </div>
            
            <div className="board-row ">
            <Sequare xturn={xturn}  onClick={()=>{handleClick(3)}} value={state[3]}/>
            <Sequare xturn={xturn}  onClick={()=>{handleClick(4)}} value={state[4]}/>
            <Sequare xturn={xturn}  onClick={()=>{handleClick(5)}} value={state[5]}/>
            </div>
         <div className="board-row">
         <Sequare xturn={xturn}  onClick={()=>{handleClick(6)}} value={state[6]}/>
         <Sequare xturn={xturn} onClick={()=>{handleClick(7)}} value={state[7]}/>
         <Sequare xturn={xturn}  onClick={()=>{handleClick(8)}} value={state[8]}/>
         </div></>
         )}
         <button onClick={resetbtn} className="button">RESET</button>

         </div>
  
   );
}
 export default Tictoe;
